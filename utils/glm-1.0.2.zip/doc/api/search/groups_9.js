var searchData=
[
  ['vector_20relational_20functions_4534',['Vector Relational Functions',['../a00985.html',1,'']]],
  ['vector_20types_4535',['Vector types',['../a00890.html',1,'']]],
  ['vector_20types_20with_20precision_20qualifiers_4536',['Vector types with precision qualifiers',['../a00891.html',1,'']]]
];
