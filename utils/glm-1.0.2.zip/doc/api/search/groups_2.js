var searchData=
[
  ['exponential_20functions_4357',['Exponential functions',['../a00804.html',1,'']]],
  ['experimental_20extensions_4358',['Experimental extensions',['../a00896.html',1,'']]]
];
